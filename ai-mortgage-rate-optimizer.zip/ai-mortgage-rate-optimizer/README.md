
# AI Mortgage Rate Optimizer (Lightweight WordPress Plugin)

**What it is**
A lightweight, client-side simulated "AI" mortgage rate comparison and optimizer.  
Built with vanilla PHP, HTML, and JavaScript. No external API calls required.

**Features**
- Shortcode: `[ai_mortgage_optimizer]` to embed UI in pages/posts.
- Client-side simulated comparisons to demonstrate AI-driven insights.
- CSV export of results (client-side).
- PDF export via opening a printable view and using the browser's Print-to-PDF feature.
- Simple, modern UI and mobile responsive.

**Installation**
1. Upload the `ai-mortgage-rate-optimizer` folder into `wp-content/plugins/`.
2. Activate the plugin in WordPress admin.
3. Add shortcode `[ai_mortgage_optimizer]` to any page or post.

**Notes & Future enhancements**
- Replace simulation logic with real ranking API / search API or lender data for production.
- Add server-side PDF generation if needed (requires libraries).
- Add settings page for branding and default values.

**Disclaimer**
Results are AI-generated for educational use only. Always verify with experts and follow AI regulations.
