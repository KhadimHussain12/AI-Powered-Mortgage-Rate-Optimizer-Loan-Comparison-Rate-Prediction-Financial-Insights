
(function(){
    // Utility functions
    function numberWithCommas(x){
        return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    function generateSimulatedProviders(loanAmount, termYears, creditScore, zip, negotiate){
        // Basic seed list of lenders
        var lenders = [
            {name: "Community Lender"},
            {name: "National Bank"},
            {name: "Online Lender"},
            {name: "Credit Union"},
            {name: "Regional Mortgage Co."}
        ];

        var baseRate = 3.25; // base market rate - simulated
        // adjust base on zip (small random), credit score, and term
        var zipAdj = (parseInt(zip.replace(/\D/g,"")) || 0) % 10 / 100; // tiny adjust
        var creditAdj = (720 - creditScore) / 1000; // e.g. 720->0
        var termAdj = (termYears === 30) ? 0.25 : (termYears === 15 ? -0.15 : 0.05);

        // Create results
        var results = lenders.map(function(l,i){
            var volatility = (i - 2) * 0.05; // different lenders vary
            var rate = baseRate + zipAdj + creditAdj + termAdj + volatility + (Math.random()*0.2 - 0.1);
            // negotiation may reduce rate by up to 0.2%
            if(negotiate && Math.random() > 0.5) rate -= (Math.random() * 0.25);
            // round
            rate = Math.max(0.5, Math.round(rate * 100) / 100);
            var monthly = (rate / 100 / 12);
            var n = termYears * 12;
            var payment = (monthly * loanAmount) / (1 - Math.pow(1 + monthly, -n));
            payment = Math.round(payment);
            var total = Math.round(payment * n);
            return {
                lender: l.name,
                rate: rate,
                monthly: payment,
                total: total
            };
        });

        // Sort by best rate
        results.sort(function(a,b){return a.rate - b.rate});
        // Add AI score (simulated)
        results = results.map(function(r, idx){
            r.aiScore = Math.max(60, 95 - idx*6 - Math.round(Math.random()*6));
            return r;
        });
        return results;
    }

    function renderResults(results){
        var container = document.getElementById('ai-results');
        if(!container) return;
        if(results.length === 0){
            container.innerHTML = '<p>No results</p>';
            return;
        }
        var html = '<table><thead><tr><th>Lender</th><th>Rate (%)</th><th>Monthly (USD)</th><th>Total Payment</th><th>AI Score</th></tr></thead><tbody>';
        results.forEach(function(r){
            html += '<tr><td>' + r.lender + '</td><td>' + r.rate.toFixed(2) + '</td><td>$' + numberWithCommas(r.monthly) + '</td><td>$' + numberWithCommas(r.total) + '</td><td>' + r.aiScore + '</td></tr>';
        });
        html += '</tbody></table>';
        container.innerHTML = html;
    }

    function exportCSV(results){
        if(!results || !results.length) return alert('No results to export.');
        var header = ['Lender','Rate (%)','Monthly (USD)','Total Payment','AI Score'];
        var rows = results.map(function(r){ return [r.lender, r.rate.toFixed(2), r.monthly, r.total, r.aiScore]; });
        var csv = header.join(',') + '\n' + rows.map(function(r){ return r.join(','); }).join('\n');
        var blob = new Blob([csv], { type: 'text/csv' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'ai_mortgage_results.csv';
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
    }

    function exportPDF(results, formHtml){
        // We'll open a new window with printable content and trigger print.
        var win = window.open('', '_blank');
        if(!win) return alert('Please allow popups to enable PDF export (Print-to-PDF).');
        var html = '<html><head><title>AI Mortgage Results</title><meta charset="utf-8"><style>body{font-family:Arial, sans-serif;padding:20px;color:#111}table{width:100%;border-collapse:collapse}th,td{padding:8px;border:1px solid #ddd;text-align:left}</style></head><body>';
        html += '<h2>AI Mortgage Rate Optimizer — Results</h2>';
        html += formHtml || '';
        html += '<table><thead><tr><th>Lender</th><th>Rate (%)</th><th>Monthly (USD)</th><th>Total Payment</th><th>AI Score</th></tr></thead><tbody>';
        results.forEach(function(r){
            html += '<tr><td>' + r.lender + '</td><td>' + r.rate.toFixed(2) + '</td><td>$' + numberWithCommas(r.monthly) + '</td><td>$' + numberWithCommas(r.total) + '</td><td>' + r.aiScore + '</td></tr>';
        });
        html += '</tbody></table>';
        html += '<p>Disclaimer: Results are AI-generated for educational use only. Always verify with experts.</p>';
        html += '</body></html>';
        win.document.open();
        win.document.write(html);
        win.document.close();
        // Give the new window a moment to render then call print
        setTimeout(function(){ win.print(); }, 600);
    }

    // State holder
    var lastResults = [];

    // Attach event listeners when DOM ready
    document.addEventListener('DOMContentLoaded', function(){
        var runBtn = document.getElementById('aiRun');
        var resetBtn = document.getElementById('aiReset');
        var csvBtn = document.getElementById('exportCsv');
        var pdfBtn = document.getElementById('exportPdf');

        function collectForm(){
            var loanAmount = parseFloat(document.getElementById('loanAmount').value) || 0;
            var term = parseInt(document.getElementById('term').value) || 30;
            var creditScore = parseInt(document.getElementById('creditScore').value) || 700;
            var zip = document.getElementById('zip').value || '';
            var negotiate = document.getElementById('negotiate').value === '1';
            return {loanAmount, term, creditScore, zip, negotiate};
        }

        function createFormSnapshotHtml(vals){
            return '<p><strong>Loan:</strong> $' + numberWithCommas(vals.loanAmount) + ' &nbsp; <strong>Term:</strong> ' + vals.term + ' yrs &nbsp; <strong>Credit Score:</strong> ' + vals.creditScore + '</p>';
        }

        if(runBtn){
            runBtn.addEventListener('click', function(e){
                e.preventDefault();
                var vals = collectForm();
                lastResults = generateSimulatedProviders(vals.loanAmount, vals.term, vals.creditScore, vals.zip, vals.negotiate);
                renderResults(lastResults);
            });
        }

        if(resetBtn){
            resetBtn.addEventListener('click', function(){
                document.getElementById('loanAmount').value = 300000;
                document.getElementById('term').value = 30;
                document.getElementById('creditScore').value = 720;
                document.getElementById('zip').value = '';
                document.getElementById('negotiate').value = '0';
                lastResults = [];
                var container = document.getElementById('ai-results');
                if(container) container.innerHTML = '';
            });
        }

        if(csvBtn){
            csvBtn.addEventListener('click', function(){
                exportCSV(lastResults);
            });
        }

        if(pdfBtn){
            pdfBtn.addEventListener('click', function(){
                var vals = collectForm();
                var formHtml = createFormSnapshotHtml(vals);
                exportPDF(lastResults, formHtml);
            });
        }
    });
})();
